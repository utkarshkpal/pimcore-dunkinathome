﻿function trackSubmitClick() {
    _gaq.push(["_trackEvent", "Sign Up", "Click", "Submit", null]);
}