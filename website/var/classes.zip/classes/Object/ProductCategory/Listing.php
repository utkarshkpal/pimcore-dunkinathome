<?php 

namespace Pimcore\Model\Object\ProductCategory;

use Pimcore\Model\Object;

/**
 * @method Object\ProductCategory current()
 */

class Listing extends Object\Listing\Concrete {

public $classId = 2;
public $className = "ProductCategory";


}
