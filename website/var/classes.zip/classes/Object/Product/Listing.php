<?php 

namespace Pimcore\Model\Object\Product;

use Pimcore\Model\Object;

/**
 * @method Object\Product current()
 */

class Listing extends Object\Listing\Concrete {

public $classId = 1;
public $className = "Product";


}
