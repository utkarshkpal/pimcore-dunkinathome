<?php 

/** 
* Generated at: 2016-11-08T12:51:01+01:00
* Inheritance: no
* Variants: no
* Changed by: admin (2)
* IP: 192.168.8.30


Fields Summary: 
*/ 

namespace Pimcore\Model\Object;



/**
*/

class Dsd extends Concrete {

public $o_classId = 3;
public $o_className = "dsd";


/**
* @param array $values
* @return \Pimcore\Model\Object\Dsd
*/
public static function create($values = array()) {
	$object = new static();
	$object->setValues($values);
	return $object;
}

}

