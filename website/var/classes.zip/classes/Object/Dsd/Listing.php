<?php 

namespace Pimcore\Model\Object\Dsd;

use Pimcore\Model\Object;

/**
 * @method Object\Dsd current()
 */

class Listing extends Object\Listing\Concrete {

public $classId = 3;
public $className = "dsd";


}
