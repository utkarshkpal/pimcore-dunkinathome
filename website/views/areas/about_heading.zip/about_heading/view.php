<section class="introduction col7">

<h1 class="introduction-heading"><?= $this->image("title",["hidetext"=>true]);?></h1>


<?php if($this->editmode) {
echo $this->wysiwyg("content",["placeholder" => "Main Heading","title" => "Main Heading","limit"=>1]);
} else {
  echo $this->wysiwyg("content")->text;
}
?>

</section>
<br class="clear">
