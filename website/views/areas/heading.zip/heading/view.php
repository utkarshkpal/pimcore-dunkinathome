
 <section class="introduction col8">
<h1 class="introduction-heading"><?= $this->image("title",["hidetext"=>true]);?></h1>
 <p><?= $this->wysiwyg("desc",["placeholder"=>"Enter Description","height"=>100, "title"=>"Enter Description"]);?></p>
  </section>
