<section class="introduction col7">

<h1 class="introduction-heading">
  <?= $this->image("headingTitle") ; ?>
</h1>

<?php
echo  $this->wysiwyg("headingDesc");
?>

</section>
<br class="clear">
